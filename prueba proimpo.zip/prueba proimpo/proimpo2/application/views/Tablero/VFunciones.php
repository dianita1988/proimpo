<script type="text/javascript">
    $(document).ready(function() {
        $('#TablaClientes').DataTable( {
            "processing": true,
            "serverSide": false,
            "responsive": true,
            "language": {
                "url": "./assets/Spanish.json"
            },
            "ajax": {
                "url": "CClientes/TablaClientes",
                "type": "POST"
            },
            "columns": [
            { "data": "Cedula" },
            { "data": "Nombres" },
            { "data": "Apellidos" },
            { "data": "Edad" },
            { "data": "Genero" },
            { "data": "Ciudad" },
            ]
        } );
    } );

    $("#BtnGuardarCliente").click(function() {

        $('#FormClientes').validate({
        rules: {
            cedula: { required: true, digits: true},
            nombres: { required: true},
            apellidos: { required: true},
            edad: { required: true, digits: true, maxlength: 2},
            genero: { required: true , maxlength: 1},
            ciudad: { required: true}
        },
        messages: {

            cedula: {required:"Cedula requerida", digits:"Solo se permiten números"},
            nombres: {required:"Nombre requeridos"},
            apellidos: {required:"Apellidos requeridos"},
            edad: {required:"Edad requerida", digits:"Solo se permiten números", maxlength: "Máximo 2 dígitos"},
            genero: {required:"El género requerido"},
            ciudad: {required:"La ciudad es requerida"},

        },
        submitHandler: function(form){
            event.preventDefault();

        $.ajax({
            url: 'CClientes/GuardarClientes',
            type: 'Post',
            data:$("#FormClientes").serialize(),
        })
        .done(function(response) {

           if (response== '1') {
             Swal.fire({
              icon: 'success',
              title: 'Registro guardado',
              showConfirmButton: false,
              timer: 2000
          }).then(() => {

            let table = $('#TablaClientes').DataTable();
            table.ajax.reload(null, false);
        })

      }else{
        Swal.fire({
          icon: 'error',
          title: 'El registro no fue guardado',
          showConfirmButton: false,
          timer: 2000
      })
    }
})
        .fail(function() {
            console.log("error");
        })
        }
    })







    });
</script>
