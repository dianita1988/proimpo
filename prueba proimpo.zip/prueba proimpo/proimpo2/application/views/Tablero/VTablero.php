<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="row">
        <div class="col-md-3">
            <div class="card shadow mb-6">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold" style="color: #102EEF;">Formulario de registro</h6>
                </div>
                <div class="card-body">
                    <form id="FormClientes">
                      <div class="form-group">
                        <label for="">Cédula</label>
                        <input type="text" class="form-control" id="cedula" name="cedula">
                    </div>
                    <div class="form-group">
                        <label for="">Nombres</label>
                        <input type="text" class="form-control" id="nombres" name="nombres">
                    </div>
                    <div class="form-group">
                        <label for="">Apellidos</label>
                        <input type="text" class="form-control" id="apellidos" name="apellidos">
                    </div>
                    <div class="form-group">
                        <label for="">Edad</label>
                        <input type="text" class="form-control" id="edad" name="edad">
                        <div class="form-group">
                            <label for="">Género</label>
                            <input type="text" class="form-control" id="genero" name="genero">
                        </div>
                        <div class="form-group">
                            <label for="">Ciudad</label>
                            <input type="text" class="form-control" id="ciudad" name="ciudad">
                        </div>                    
                    </div>                    
                    <button type="submit" class="btn btn-primary" id="BtnGuardarCliente" style="background-color: #102EEF; float: right;">Guardar</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-9">
    <div class="card shadow mb-6">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold" style="color: #102EEF;">Tabla de registros</h6>
        </div>
        <div class="card-body">
                <table id="TablaClientes" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Cédula</th>
                            <th>Nombres</th>
                            <th>Apellidos</th>
                            <th>Edad</th>
                            <th>Género</th>
                            <th>Ciudad</th>                           
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
<!-- /.container-fluid -->

</div>
            <!-- End of Main Content -->