<script type="text/javascript">
	$("#login").click(function(event) {
		
		$.ajax({
			url: 'CLogin/Validar',
			type: 'POST',
			dataType: 'json',
			data: $("#FormLogin").serialize(),
		})
		.done(function(response) {
			
			if (response.codigo== 0 || response.codigo== 1) {

				Swal.fire({
							  icon: 'error',
							  title: response.mensaje,
							  showConfirmButton: false,
							  timer: 3000
							})
			}else{

				Swal.fire({
					  icon: 'success',
					  title: 'Bievenido',
					  showConfirmButton: false,
					  timer: 1500
					}).then(() => {

						location.href = 'CTablero'
					})
			}
		})
		.fail(function() {
			console.log("error");
		})
		
	});

</script>