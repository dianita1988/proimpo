<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CInicio extends CI_Controller {

	public function index()
	{
		if($this->session->userdata('cedula'))
	{
		redirect('CTablero');
	}
		$this->load->view('Inicio/VInicio');
		$this->load->view('Inicio/VFunciones');

	}

}

/* End of file CInicio.php */
/* Location: ./application/controllers/CInicio.php */