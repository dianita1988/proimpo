<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class CClientes extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('MClientes');
	}
	public function TablaClientes()
	{
		$ejecucion['data']=$this->MClientes->TablaClientes();

		echo json_encode($ejecucion);
	}

	public function GuardarClientes()
	{	

		$ejecucion= $this->MClientes->GuardarClientes($this->input->post());
		if ($ejecucion['code']== 0) {
			
			echo '1';
		}else{
			echo '0';
		}
	}

}

/* End of file CClientes.php */
/* Location: ./application/controllers/CClientes.php */