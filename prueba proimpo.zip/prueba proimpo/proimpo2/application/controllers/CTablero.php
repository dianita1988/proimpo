<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CTablero extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('cedula')){
			redirect('CInicio','refresh');
		}
	}

	public function index()
	{	
		$this->load->view('Base/VHead');
		$this->load->view('Base/VSidebar');
		$this->load->view('Base/VTopbar');
		$this->load->view('Tablero/VTablero');
		$this->load->view('Base/VFooter');
		$this->load->view('Tablero/VFunciones');
	}

}

/* End of file CTablero.php */
/* Location: ./application/controllers/CTablero.php */