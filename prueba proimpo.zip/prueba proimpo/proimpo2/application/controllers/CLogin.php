<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CLogin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('MLogin');
	}

	public function Validar()
	{
		
		$datos = $this->input->post();


		$ejecucion = $this->MLogin->Validar($datos['Usuario']);

		if (empty($ejecucion)) 
		{
			$respuesta=array("codigo" => 0, "mensaje"=>"El usuario no existe.");
		}else{

			if (password_verify($datos['Clave'] , $ejecucion['pass']))
			{
			     $respuesta=array("codigo" => 2, "mensaje"=>"datos correctos");
			     $this->session->set_userdata($ejecucion);
			     
			} else {
			     $respuesta=array("codigo" => 1, "mensaje"=>"La contraseña es incorrecta");
			}
		}

		echo json_encode($respuesta);	
	}

public function Cerrar()
{
	$this->session->sess_destroy();

	redirect('CInicio','refresh');
}
	public function GenerarClave($value='')
	{
		echo password_hash("a123", PASSWORD_BCRYPT)."\n";
	}

}

/* End of file CLogin.php */
/* Location: ./application/controllers/CLogin.php */