<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MLogin extends CI_Model {
	
	public function __construct(){
		parent::__construct();
	}

	public function Validar($cedula){
		$sql = "SELECT * FROM usuario WHERE cedula='$cedula'";
		$datos = $this->db->query($sql)->row_array();
		return $datos;
	}

	// public function usuario($cedula){
	// 	$sql = "select * from usuario where cedula=$cedula";
	// 	$datos = $this->db->query($sql)->result_array();
	// 	return $datos;
	// }

	// public function consultar(){
	// 	$sql = "select * from usuario";
	// 	$datos = $this->db->query($sql)->result_array();
	// 	return $datos;
	// }

	// public function crear(){
	// 	$pass =  password_hash('147', password_default);
	// 	$sql = "insert into usuario value('12345','Elizabeth','Gomez','carrera 1D','3213262','estudiante','$pass')";
	// 	$datos = $this->db->query($sql)->result_array();
	// 	return $datos;
	// }
}

/* End of file MLogin.php */
/* Location: ./application/models/MLogin.php */