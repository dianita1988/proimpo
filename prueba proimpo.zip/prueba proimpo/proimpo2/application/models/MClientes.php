<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MClientes extends CI_Model {
	
	public function __construct(){
		parent::__construct();
	}

	public function TablaClientes(){
		$sql = "SELECT * FROM clientes";
		$datos = $this->db->query($sql)->result_array();
		return $datos;
	}

public function GuardarClientes($data)
{
		$sql = " CALL InsertarCliente (?,?,?,?,?,?)";
		$datos = $this->db->query($sql, array_values($data));
		return $this->db->error();
}

}

/* End of file MClientes.php */
/* Location: ./application/models/MClientes.php */